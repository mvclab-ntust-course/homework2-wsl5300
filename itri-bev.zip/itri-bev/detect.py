# YOLOv5 🚀 by Ultralytics, AGPL-3.0 license
"""
Run YOLOv5 detection inference on images, videos, directories, globs, YouTube, webcam, streams, etc.

Usage - sources:
    $ python detect.py --weights yolov5s.pt --source 0                               # webcam
                                                     img.jpg                         # image
                                                     vid.mp4                         # video
                                                     screen                          # screenshot
                                                     path/                           # directory
                                                     list.txt                        # list of images
                                                     list.streams                    # list of streams
                                                     'path/*.jpg'                    # glob
                                                     'https://youtu.be/LNwODJXcvt4'  # YouTube
                                                     'rtsp://example.com/media.mp4'  # RTSP, RTMP, HTTP stream

Usage - formats:
    $ python detect.py --weights yolov5s.pt                 # PyTorch
                                 yolov5s.torchscript        # TorchScript
                                 yolov5s.onnx               # ONNX Runtime or OpenCV DNN with --dnn
                                 yolov5s_openvino_model     # OpenVINO
                                 yolov5s.engine             # TensorRT
                                 yolov5s.mlmodel            # CoreML (macOS-only)
                                 yolov5s_saved_model        # TensorFlow SavedModel
                                 yolov5s.pb                 # TensorFlow GraphDef
                                 yolov5s.tflite             # TensorFlow Lite
                                 yolov5s_edgetpu.tflite     # TensorFlow Edge TPU
                                 yolov5s_paddle_model       # PaddlePaddle
"""

import argparse
import csv
import os
import platform
import sys
from pathlib import Path
import numpy as np
import math

import torch

FILE = Path(__file__).resolve()
ROOT = FILE.parents[0]  # YOLOv5 root directory
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))  # add ROOT to PATH
ROOT = Path(os.path.relpath(ROOT, Path.cwd()))  # relative

from ultralytics.utils.plotting import Annotator, colors, save_one_box

from models.common import DetectMultiBackend
from utils.dataloaders import IMG_FORMATS, VID_FORMATS, LoadImages, LoadScreenshots, LoadStreams
from utils.general import (
    LOGGER,
    Profile,
    check_file,
    check_img_size,
    check_imshow,
    check_requirements,
    colorstr,
    cv2,
    increment_path,
    non_max_suppression,
    print_args,
    scale_boxes,
    strip_optimizer,
    xyxy2xywh,
)
from utils.torch_utils import select_device, smart_inference_mode

depth_log_filename = './depth.log'

def draw_grid(img, grid_shape, color=(0, 200, 0), thickness=1):
    h, w, _ = img.shape
    #rows, cols = grid_shape
    #dy, dx = h / rows, w / cols
    dy, dx = grid_shape

    rows, cols = int(round(h / dy)), int(round(w / dx))

    # draw vertical lines
    for x in np.linspace(start=0, stop=w, num=cols-1):
        x = int(x)
        cv2.line(img, (x, 0), (x, h), color=color, thickness=thickness)

    # draw horizontal lines
    for y in np.linspace(start=0, stop=h, num=rows-1):
        y = int(y)
        cv2.line(img, (0, y), (w, y), color=color, thickness=thickness)

    return img

def plot_object_bev(transformed_image_with_centroids, depth_np, src_points ,dst_points , objs_, original_size, bev_frame_size, grid_size=30):

    M = cv2.getPerspectiveTransform(src_points, dst_points)
    
    persObjs = []
    ## mark objs and ids
    for obj_ in objs_:
        if obj_:
            x, y, w, h = obj_[0]
            # Create a numpy array of the centroid coordinates
            #centroid_coords = np.array([[x, y]], dtype=np.float32) # use box center point
            centroid_coords = np.array([[x, y + (h / 2)]], dtype=np.float32) # use box bottom middle point
            centroid_coords[0][0] *= original_size[0]
            centroid_coords[0][1] *= original_size[1]
            
            # Apply the perspective transformation to the centroid coordinates
            transformed_coords = cv2.perspectiveTransform(centroid_coords.reshape(-1, 1, 2), M)
            transformed_coords_ = transformed_coords[0][0].astype(int)
            
            depth_value = obj_[2]


            transformed_coords_[1] = bev_frame_size[1] - depth_value * grid_size

            # Draw a circle at the transformed centroid location
            cv2.circle(transformed_image_with_centroids, (transformed_coords_[0], transformed_coords_[1]), radius=3, color=(0, 255, 0), thickness=-1)
            cv2.circle(transformed_image_with_centroids, (transformed_coords_[0], transformed_coords_[1]), radius=12, color=(255, 255, 255), thickness=1)
            # print("centroid_coords: ", centroid_coords)
            # print("transformed_coords_: ", transformed_coords_)
            class_text = f"Class: {obj_[1]} {depth_value:.2f}m"

            car_width_m = 1.76
            car_length_m = 4.48

            cv2.putText(transformed_image_with_centroids, class_text, (transformed_coords_[0] + 10, transformed_coords_[1]), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
            cv2.rectangle(transformed_image_with_centroids, (transformed_coords_[0] - int(car_width_m / 2 * grid_size), transformed_coords_[1] - int(car_length_m * grid_size)), (transformed_coords_[0] + int(car_width_m / 2 * grid_size), transformed_coords_[1]), (255,0,0), 2)
            # persObjs.append([transformed_coords_, obj_[1]])

    return transformed_image_with_centroids, persObjs


def get_bbox_depth(image, bbox_list):
    
    bbox_list_depth = []
    # bbox_list = [(label, c, *xywh, confidence_str)]
    for bbox in bbox_list:
        label, c, x, y, w, h, confidence_str = bbox
        # 计算边界框在图像中的像素坐标
        tl = int((x - w / 2) * image.shape[1]), int((y - h / 2) * image.shape[0])  # 左上角坐标
        br = int((x + w / 2) * image.shape[1]), int((y + h / 2) * image.shape[0])  # 右下角坐标
        # 裁剪图像区域
        cropped_region = image[tl[1]:br[1], tl[0]:br[0]]
        
        # 计算裁剪区域的中值并添加到列表中
        median_value = np.median(cropped_region)
        median_value = round(median_value, 2)
        bbox_list_depth.append(median_value)
    
    return bbox_list_depth



def draw_bbox(image, bbox_list, bbox_list_depth, line_thickness):
        
    # bbox_list = [(label, c, *xywh, confidence_str)]
    for idx, bbox in enumerate(bbox_list):
        label, c, x, y, w, h, confidence_str = bbox
        # 计算边界框在图像中的像素坐标
        tl = int((x - w / 2) * image.shape[1]), int((y - h / 2) * image.shape[0])  # 左上角坐标
        br = int((x + w / 2) * image.shape[1]), int((y + h / 2) * image.shape[0])  # 右下角坐标
        
        # 绘制边界框
        color=colors(c, True)
        cv2.rectangle(image, tl, br, color, line_thickness)
        
        # 在边界框上方绘制标签和置信度
        text = f"dist:{str(bbox_list_depth[idx])}m, {label} {confidence_str}"
        # print(text, label)
        # 获取文本大小
        (text_width, text_height), _ = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.8, 2)

        # 绘制文本底色
        cv2.rectangle(image, (tl[0], tl[1] - text_height - 5), (tl[0] + text_width, tl[1]), color, -1)
        
        
        cv2.putText(image, text, (tl[0], tl[1] - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
    
    return image

@smart_inference_mode()
def run(
    weights=ROOT / "yolov5s.pt",  # model path or triton URL
    source=ROOT / "data/images",  # file/dir/URL/glob/screen/0(webcam)
    data=ROOT / "data/coco128.yaml",  # dataset.yaml path
    imgsz=(640, 640),  # inference size (height, width)
    conf_thres=0.25,  # confidence threshold
    iou_thres=0.45,  # NMS IOU threshold
    max_det=1000,  # maximum detections per image
    device="",  # cuda device, i.e. 0 or 0,1,2,3 or cpu
    view_img=False,  # show results
    save_txt=False,  # save results to *.txt
    save_csv=False,  # save results in CSV format
    save_conf=False,  # save confidences in --save-txt labels
    save_crop=False,  # save cropped prediction boxes
    nosave=False,  # do not save images/videos
    classes=None,  # filter by class: --class 0, or --class 0 2 3
    agnostic_nms=False,  # class-agnostic NMS
    augment=False,  # augmented inference
    visualize=False,  # visualize features
    update=False,  # update all models
    project=ROOT / "runs/detect",  # save results to project/name
    name="exp",  # save results to project/name
    exist_ok=False,  # existing project/name ok, do not increment
    line_thickness=3,  # bounding box thickness (pixels)
    hide_labels=False,  # hide labels
    hide_conf=False,  # hide confidences
    half=False,  # use FP16 half-precision inference
    dnn=False,  # use OpenCV DNN for ONNX inference
    vid_stride=1,  # video frame-rate stride
    run_liteMono=False,
    run_bev=False,
    saveVideo_liteMono=False,
    depth_log=False,
    save_bev_video=False,
    save_bev_warp_video=False,
):
    source = str(source)
    save_img = not nosave and not source.endswith(".txt")  # save inference images
    is_file = Path(source).suffix[1:] in (IMG_FORMATS + VID_FORMATS)
    is_url = source.lower().startswith(("rtsp://", "rtmp://", "http://", "https://"))
    webcam = source.isnumeric() or source.endswith(".streams") or (is_url and not is_file)
    screenshot = source.lower().startswith("screen")
    if is_url and is_file:
        source = check_file(source)  # download

    if run_liteMono:
        import time
        import os
        import networks
        from layers import disp_to_depth
        from torchvision import transforms
        
    # Directories
    save_dir = increment_path(Path(project) / name, exist_ok=exist_ok)  # increment run
    (save_dir / "labels" if save_txt else save_dir).mkdir(parents=True, exist_ok=True)  # make dir

    # Load model
    device = select_device(device)
    model = DetectMultiBackend(weights, device=device, dnn=dnn, data=data, fp16=half)
    stride, names, pt = model.stride, model.names, model.pt
    imgsz = check_img_size(imgsz, s=stride)  # check image size
    print("imgsz:")
    print(imgsz)

    # Dataloader
    bs = 1  # batch_size
    if webcam:
        view_img = check_imshow(warn=True)
        dataset = LoadStreams(source, img_size=imgsz, stride=stride, auto=pt, vid_stride=vid_stride)
        bs = len(dataset)
    elif screenshot:
        dataset = LoadScreenshots(source, img_size=imgsz, stride=stride, auto=pt)
    else:
        dataset = LoadImages(source, img_size=imgsz, stride=stride, auto=pt, vid_stride=vid_stride)
    vid_path, vid_writer = [None] * bs, [None] * bs

    # Run inference
    if run_liteMono:
        cv2.namedWindow("yolov5_lite-mono", cv2.WINDOW_NORMAL)
        #if run_bev:
        #    cv2.namedWindow("Transformed Frame", cv2.WINDOW_NORMAL)
            

        LiteMono_load_weights_folder = 'Lite-Mono_pretrain_weight'
        LiteMono_model = 'lite-mono-8m' # "lite-mono", "lite-mono-small", "lite-mono-tiny", "lite-mono-8m"

        print("-> Loading Lite-Mono model from ", LiteMono_load_weights_folder)
        encoder_path = os.path.join(LiteMono_load_weights_folder, LiteMono_model + "_640x192", "encoder.pth")
        decoder_path = os.path.join(LiteMono_load_weights_folder, LiteMono_model + "_640x192", "depth.pth")

        encoder_dict = torch.load(encoder_path)
        decoder_dict = torch.load(decoder_path)

        # extract the height and width of image that this model was trained with
        feed_height = encoder_dict['height']
        feed_width = encoder_dict['width']
        print('feed_height, feed_width:', feed_height, feed_width)

        # LOADING PRETRAINED MODEL
        print("   Loading pretrained encoder")
        encoder = networks.LiteMono(model=LiteMono_model,
                                        height=feed_height,
                                        width=feed_width)

        model_dict = encoder.state_dict()
        encoder.load_state_dict({k: v for k, v in encoder_dict.items() if k in model_dict})

        encoder.to(device)
        encoder.eval()

        print("   Loading pretrained decoder")
        depth_decoder = networks.DepthDecoder(encoder.num_ch_enc, scales=range(3))
        depth_model_dict = depth_decoder.state_dict()
        depth_decoder.load_state_dict({k: v for k, v in decoder_dict.items() if k in depth_model_dict})

        depth_decoder.to(device)
        depth_decoder.eval()

        elapsed_time = 0
        max_memory_allocated = 0
        frame_count = 0
        
        if saveVideo_liteMono:
            firstOutVideo = True
    if depth_log :
        depth_log_file = open(depth_log_filename,'w+')

    first_save_bev_video = True
    first_save_bev_warp_video = True
            
    model.warmup(imgsz=(1 if pt or model.triton else bs, 3, *imgsz))  # warmup
    seen, windows, dt = 0, [], (Profile(device=device), Profile(device=device), Profile(device=device))
    for path, im, im0s, vid_cap, s in dataset:
        with dt[0]:
            im = torch.from_numpy(im).to(model.device)
            im = im.half() if model.fp16 else im.float()  # uint8 to fp16/32
            im /= 255  # 0 - 255 to 0.0 - 1.0
            if len(im.shape) == 3:
                im = im[None]  # expand for batch dim
            if model.xml and im.shape[0] > 1:
                ims = torch.chunk(im, im.shape[0], 0)

        # Inference
        with dt[1]:
            visualize = increment_path(save_dir / Path(path).stem, mkdir=True) if visualize else False
            if model.xml and im.shape[0] > 1:
                pred = None
                for image in ims:
                    if pred is None:
                        pred = model(image, augment=augment, visualize=visualize).unsqueeze(0)
                    else:
                        pred = torch.cat((pred, model(image, augment=augment, visualize=visualize).unsqueeze(0)), dim=0)
                pred = [pred, None]
            else:
                pred = model(im, augment=augment, visualize=visualize)
        # NMS
        with dt[2]:
            pred = non_max_suppression(pred, conf_thres, iou_thres, classes, agnostic_nms, max_det=max_det)

        # Second-stage classifier (optional)
        # pred = utils.general.apply_classifier(pred, classifier_model, im, im0s)

        # Define the path for the CSV file
        csv_path = save_dir / "predictions.csv"

        # Create or append to the CSV file
        def write_to_csv(image_name, prediction, confidence):
            """Writes prediction data for an image to a CSV file, appending if the file exists."""
            data = {"Image Name": image_name, "Prediction": prediction, "Confidence": confidence}
            with open(csv_path, mode="a", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=data.keys())
                if not csv_path.is_file():
                    writer.writeheader()
                writer.writerow(data)

        # Process predictions
        if run_liteMono:
            # bbox_list = [(label, c, *xywh, confidence_str)]
            bbox_list = []
            if run_bev:
                bev_objs = []
                
            
        for i, det in enumerate(pred):  # per image
            seen += 1
            if webcam:  # batch_size >= 1
                p, im0, frame = path[i], im0s[i].copy(), dataset.count
                s += f"{i}: "
            else:
                p, im0, frame = path, im0s.copy(), getattr(dataset, "frame", 0)

            p = Path(p)  # to Path
            save_path = str(save_dir / p.name)  # im.jpg
            txt_path = str(save_dir / "labels" / p.stem) + ("" if dataset.mode == "image" else f"_{frame}")  # im.txt
            s += "%gx%g " % im.shape[2:]  # print string
            gn = torch.tensor(im0.shape)[[1, 0, 1, 0]]  # normalization gain whwh
            imc = im0.copy() if save_crop else im0  # for save_crop
            if run_liteMono:
                im0_org = im0.copy()

            annotator = Annotator(im0, line_width=line_thickness, example=str(names))
            if len(det):
                # Rescale boxes from img_size to im0 size
                det[:, :4] = scale_boxes(im.shape[2:], det[:, :4], im0.shape).round()

                # Print results
                for c in det[:, 5].unique():
                    n = (det[:, 5] == c).sum()  # detections per class
                    s += f"{n} {names[int(c)]}{'s' * (n > 1)}, "  # add to string

                # Write results
                for *xyxy, conf, cls in reversed(det):
                    c = int(cls)  # integer class
                    label = names[c] if hide_conf else f"{names[c]}"
                    confidence = float(conf)
                    confidence_str = f"{confidence:.2f}"

                    if save_csv:
                        write_to_csv(p.name, label, confidence_str)

                    if save_txt:  # Write to file
                        xywh = (xyxy2xywh(torch.tensor(xyxy).view(1, 4)) / gn).view(-1).tolist()  # normalized xywh
                        line = (cls, *xywh, conf) if save_conf else (cls, *xywh)  # label format
                        with open(f"{txt_path}.txt", "a") as f:
                            f.write(("%g " * len(line)).rstrip() % line + "\n")

                    if save_img or save_crop or view_img:  # Add bbox to image
                        c = int(cls)  # integer class
                        label = None if hide_labels else (names[c] if hide_conf else f"{names[c]} {conf:.2f}")
                        annotator.box_label(xyxy, label, color=colors(c, True))
                    if save_crop:
                        save_one_box(xyxy, imc, file=save_dir / "crops" / names[c] / f"{p.stem}.jpg", BGR=True)
                    
                    if run_liteMono:
                        xywh = (xyxy2xywh(torch.tensor(xyxy).view(1, 4)) / gn).view(-1).tolist()  # normalized xywh
                        # label format
                        bbox_list.append((names[c], c, *xywh, confidence_str))
                        if run_bev:
                            #print(xywh)
                            #print(type(xywh))
                            bev_objs.append([(xywh[0],xywh[1],xywh[2],xywh[3]), names[c]])

            # Stream results
            im0 = annotator.result()
            if view_img:
                if platform.system() == "Linux" and p not in windows:
                    windows.append(p)
                    cv2.namedWindow(str(p), cv2.WINDOW_NORMAL | cv2.WINDOW_KEEPRATIO)  # allow window resize (Linux)
                    cv2.resizeWindow(str(p), im0.shape[1], im0.shape[0])
                #cv2.imshow(str(p), im0) 
                cv2.waitKey(1)  # 1 millisecond

            # Save results (image with detections)
            if save_img:
                if dataset.mode == "image":
                    cv2.imwrite(save_path, im0)
                else:  # 'video' or 'stream'
                    if vid_path[i] != save_path:  # new video
                        vid_path[i] = save_path
                        if isinstance(vid_writer[i], cv2.VideoWriter):
                            vid_writer[i].release()  # release previous video writer
                        if vid_cap:  # video
                            fps = vid_cap.get(cv2.CAP_PROP_FPS)
                            w = int(vid_cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                            h = int(vid_cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                        else:  # stream
                            fps, w, h = 30, im0.shape[1], im0.shape[0]
                        save_path = str(Path(save_path).with_suffix(".mp4"))  # force *.mp4 suffix on results videos
                        vid_writer[i] = cv2.VideoWriter(save_path, cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
                    vid_writer[i].write(im0)
                    
            if run_liteMono:
                # Lite-Mono run...
                frame_count += 1
    
                # Load image and preprocess
                frameLitemono = im0_org
                original_height, original_width,  _ = frameLitemono.shape
                input_image = cv2.resize(frameLitemono, (feed_width, feed_height))
                input_image = transforms.ToTensor()(input_image).unsqueeze(0)
                
                # PREDICTION
                t_start = time.time()
                
                input_image = input_image.to(device)
                features = encoder(input_image)
                outputs = depth_decoder(features)

                disp = outputs[("disp", 0)]

                disp_resized = torch.nn.functional.interpolate(
                    disp, (original_height, original_width), mode="bilinear", align_corners=False)
                
                one_image_time = time.time() - t_start
                elapsed_time += one_image_time
                #max_memory_allocated = max(max_memory_allocated,get_gpu_memory_usage())
                
                # Saving numpy file
                scaled_disp, depth = disp_to_depth(disp_resized, 0.1, 100)

                depth = depth*22.5  # 這邊要改成scale ratio，IMX477約為22.5, IMX219約為31.257
                scaled_disp = scaled_disp*22.5    # 這邊要改成scale ratio，IMX477約為22.5, IMX219約為31.257

                fps = round(1/one_image_time,2)
                print('Lite-Mono: FPS:', fps, 'inference', format(one_image_time * 1000, '.1f'), 'ms')

                # Saving colormapped depth image
                depth_np = depth.squeeze().cpu().numpy()
                scaled_disp_np = scaled_disp.squeeze().cpu().numpy()
                disp_resized_np = disp_resized.squeeze().cpu().numpy()
                pred_depth = ( disp_resized_np - np.min(disp_resized_np) ) / ( np.max(disp_resized_np) - np.min(disp_resized_np) ) * 255
                
                depth_np = depth_np.astype(np.float16)
                scaled_disp_np = scaled_disp_np.astype(np.float16)
                pred_depth = pred_depth.astype(np.uint8)
                
                # distance = depth_np[300,300] # 改成測試距離的pixel , [height, width]
                # distance = round(distance, 2)
                # print(distance)
                
                # print(len(bbox_list))
                bbox_list_depth = get_bbox_depth(depth_np, bbox_list)
                frameLitemono = draw_bbox(frameLitemono, bbox_list, bbox_list_depth, line_thickness)
                
                color_image = cv2.applyColorMap(pred_depth, cv2.COLORMAP_JET)
                                
                # yoloV5 latency
                yoloV5_latency = f"latency: {dt[1].dt * 1E3:.1f}ms"
                
                #cv2.putText(frameLitemono, yoloV5_latency, (frameLitemono.shape[1] - 160,50), cv2.FONT_HERSHEY_SIMPLEX, 1.3, (0, 255, 0), 2, cv2.LINE_AA)
                
                # lite-mono latency
                liteMono_latency = f"latency: {format(one_image_time * 1000, '.1f')} ms"
               
                # cv2.putText(color_image, str(fps) + ' fps', (60,90), cv2.FONT_HERSHEY_SIMPLEX, 3, (255,255,255), 2, cv2.LINE_AA)
                #cv2.putText(color_image, liteMono_latency, (color_image.shape[1] - 160,50), cv2.FONT_HERSHEY_SIMPLEX, 1.3, (0, 255, 0), 2, cv2.LINE_AA)
                
                # yoloV5 + lite-mono latency
                yoloV5_liteMono_latency = f"latency: {format(dt[1].dt * 1E3 + one_image_time * 1000, '.1f')} ms"
                yoloV5_liteMono_fps = f"FPS: {format(1000 / (dt[1].dt * 1E3 + one_image_time * 1000), '.1f')}"
                yoloV5_liteMono_framecount = f"frame: {frame_count}"
                
                cv2.putText(frameLitemono, yoloV5_liteMono_fps, (40,50), cv2.FONT_HERSHEY_SIMPLEX, 1.3, (0, 255, 0), 2, cv2.LINE_AA)
                cv2.putText(frameLitemono, yoloV5_liteMono_framecount, (frameLitemono.shape[1] - 300,50), cv2.FONT_HERSHEY_SIMPLEX, 1.3, (0, 255, 0), 2, cv2.LINE_AA)

                yolov5_litemono_result = np.vstack((frameLitemono, color_image))
                
                if saveVideo_liteMono:
                    if firstOutVideo:
                        firstOutVideo = False
                        # Output video parameters
                        output_path = 'yolov5_lite-mono.avi'

                        fourcc = cv2.VideoWriter_fourcc(*'XVID')          # 設定影片的格式為 XVID (for avi)
                        # fourcc = cv2.VideoWriter_fourcc(*'MJPG')          # 設定影片的格式為 MJPG (for mp4)
                        fps_out = 30.0  # Frames per second
                        # frame_size = (640, 480)  # Frame size (width, height)

                        # Get the dimensions (shape) of the image
                        height, width, channels = im0.shape
                        
                        frame_size = (width, height * 2)  # Frame size (width, height)

                        # Create a VideoWriter object for the output video
                        out = cv2.VideoWriter(output_path, fourcc, fps_out, frame_size)

                    # Write the frame to the output video
                    out.write(yolov5_litemono_result)
                # Lite-Mono run end
                
                if run_bev:
                    if depth_log :
                        depth_log_file.write(f'frame {frame_count} :\n')
                    for bev_obj in bev_objs:
                        if bev_obj:
                            _x, _y, _w, _h = bev_obj[0]
                            tl = int((_x - _w / 2) * depth_np.shape[1]), int((_y - _h / 2) * depth_np.shape[0])  # 左上角坐标
                            br = int((_x + _w / 2) * depth_np.shape[1]), int((_y + _h / 2) * depth_np.shape[0])  # 右下角坐标
                            # 裁剪图像区域
                            cropped_region = depth_np[tl[1]:br[1], tl[0]:br[0]]
                            depth_value = np.median(cropped_region)
                            bev_obj.append(depth_value)
                            if depth_log :
                                depth_log_file.write(f'\t{depth_value:.2f}\n')
                    if depth_log :
                        depth_log_file.write(f'\n\n')

                    
                    bev_warp_img = im0_org
                    
                    
                    print("run_bev")
                    #bev_map_height = original_height
                    bev_map_height = 720
                    bev_frame_height = int(bev_map_height * 1.8)
                    bev_start_y = int(bev_frame_height - bev_map_height)
                    bev_end_y = int(bev_frame_height)
                    #bev_map_width = original_width
                    bev_map_width = 420
                    bev_frame_width = int(bev_map_width * 1.8)
                    bev_start_x = int((bev_frame_width - bev_map_width) / 2)
                    bev_end_x = int(bev_frame_width - bev_start_x)

                    #frameBEV = cv2.resize(im0_org,(bev_map_width,bev_map_height))

                    transformed_image_with_centroids = np.zeros((bev_frame_height, bev_frame_width, 3), dtype=np.uint8)
                    #####################
                    ##        BEV      ##
                    #####################
                    # Define the source points (region of interest) in the original image
                    # bev_x1, bev_y1 = 10, original_height  # Top-left point
                    # bev_x2, bev_y2 = original_width * 0.4, original_height * 0.55  # Top-right point
                    # bev_x3, bev_y3 = original_width * 0.6, original_height * 0.55  # Bottom-right point
                    # bev_x4, bev_y4 = original_width - 10, original_height  # Bottom-left point
                    
                    bev_x1, bev_y1 = int(original_width * (10 / 1280)), int(original_height * (720 / 720)) # Top-left point
                    bev_x2, bev_y2 = int(original_width * (530 / 1280)), int(original_height * (400 / 720))  # Top-right point
                    bev_x3, bev_y3 = int(original_width * (840 / 1280)), int(original_height * (400 / 720))  # Bottom-right point
                    bev_x4, bev_y4 = int(original_width * (1270 / 1280)), int(original_height * (720 / 720))  # Bottom-left point         
                    
                    # # Define the source points (region of interest) in the original image
                    # x1, y1 = 10, 720  # Top-left point
                    # x2, y2 = 530, 400  # Top-right point
                    # x3, y3 = 840, 400  # Bottom-right point
                    # x4, y4 = 1270, 720  # Bottom-left point
                    
                    src_points = np.float32([(bev_x1, bev_y1), (bev_x2, bev_y2), (bev_x3, bev_y3), (bev_x4, bev_y4)])
                    # Draw the source points on the image (in red)
                    # cv2.polylines(frame, [src_points.astype(int)], isClosed=True, color=(0, 0, 255), thickness=2)

                    # # Define the destination points (desired output perspective)
                    # bev_u1, bev_v1 = bev_map_width * 0.1, bev_map_height  # Top-left point
                    # bev_u2, bev_v2 = 0, 0  # Top-right point
                    # bev_u3, bev_v3 = bev_map_width, 0  # Bottom-right point
                    # bev_u4, bev_v4 = bev_map_width * 0.9, bev_map_height  # Bottom-left point
                    
                    bev_u1, bev_v1 =  int(bev_map_width * (370 / 1280)), int(bev_map_height * (720 / 720))  # Top-left point
                    bev_u2, bev_v2 = int(bev_map_width * ((0+150) / 1280)), int(bev_map_height * (0 / 720))  # Top-right point
                    bev_u3, bev_v3 = int(bev_map_width * ((1280-150) / 1280)), int(bev_map_height * (0 / 720))  # Bottom-right point
                    bev_u4, bev_v4 = int(bev_map_width * (900 / 1280)), int(bev_map_height * (720 / 720))  # Bottom-left point

                    bev_u1, bev_v1 = bev_u1 + bev_start_x, bev_v1 + bev_start_y
                    bev_u2, bev_v2 = bev_u2 + bev_start_x, bev_v2 + bev_start_y
                    bev_u3, bev_v3 = bev_u3 + bev_start_x, bev_v3 + bev_start_y
                    bev_u4, bev_v4 = bev_u4 + bev_start_x, bev_v4 + bev_start_y

                    org_u1, org_v1 =  int(original_width * (370 / 1280)), int(original_height * (720 / 720))  # Top-left point
                    org_u2, org_v2 = int(original_width * ((0+150) / 1280)), int(original_height * (0 / 720))  # Top-right point
                    org_u3, org_v3 = int(original_width * ((1280-150) / 1280)), int(original_height * (0 / 720))  # Bottom-right point
                    org_u4, org_v4 = int(original_width * (900 / 1280)), int(original_height * (720 / 720))  # Bottom-left point
                    
                    # # Define the destination points (desired output perspective)
                    # u1, v1 = 370, 720  # Top-left point
                    # u2, v2 = 0+150, 0  # Top-right point
                    # u3, v3 = 1280-150, 0  # Bottom-right point
                    # u4, v4 = 900, 720  # Bottom-left point
                    dst_points = np.float32([[bev_u1, bev_v1], [bev_u2, bev_v2], [bev_u3, bev_v3], [bev_u4, bev_v4]])
                    org_dst_points = np.float32([[org_u1, org_v1], [org_u2, org_v2], [org_u3, org_v3], [org_u4, org_v4]])

                    cv2.line(yolov5_litemono_result, (bev_x1,bev_y1), (bev_x2,bev_y2), (0,0,255),2)
                    cv2.line(yolov5_litemono_result, (bev_x2,bev_y2), (bev_x3,bev_y3), (0,0,255),2)
                    cv2.line(yolov5_litemono_result, (bev_x3,bev_y3), (bev_x4,bev_y4), (0,0,255),2)
                    cv2.line(yolov5_litemono_result, (bev_x4,bev_y4), (bev_x1,bev_y1), (0,0,255),2)

                    bev_warp_img = cv2.warpPerspective(bev_warp_img, cv2.getPerspectiveTransform(src_points, org_dst_points), (original_width,original_height)) # Image warping
                    
                    cv2.line(bev_warp_img, (org_u1,org_v1), (org_u2,org_v2), (0,0,255),2)
                    cv2.line(bev_warp_img, (org_u2,org_v2), (org_u3,org_v3), (0,0,255),2)
                    cv2.line(bev_warp_img, (org_u3,org_v3), (org_u4,org_v4), (0,0,255),2)
                    cv2.line(bev_warp_img, (org_u4,org_v4), (org_u1,org_v1), (0,0,255),2)




                    cv2.namedWindow("bev_warp_img", cv2.WINDOW_NORMAL)
                    #cv2.namedWindow("bev_warp_img")
                    cv2.imshow("bev_warp_img", bev_warp_img)


                    cv2.line(transformed_image_with_centroids, (bev_u1,bev_v1), (bev_u2,bev_v2), (0,0,255),2)
                    cv2.line(transformed_image_with_centroids, (bev_u2,bev_v2), (bev_u3,bev_v3), (0,0,255),2)
                    cv2.line(transformed_image_with_centroids, (bev_u3,bev_v3), (bev_u4,bev_v4), (0,0,255),2)
                    cv2.line(transformed_image_with_centroids, (bev_u4,bev_v4), (bev_u1,bev_v1), (0,0,255),2)

                    bev_grid_size = 30

                    # perspectivs plot and objs
                    transformed_image_with_centroids, persObjs_ = plot_object_bev(transformed_image_with_centroids, depth_np, src_points ,dst_points , bev_objs, (original_width,original_height), (bev_frame_width, bev_frame_height),bev_grid_size)
                    



                    transformed_image_with_centroids = draw_grid(transformed_image_with_centroids, (bev_grid_size,bev_grid_size))
                    cv2.putText(transformed_image_with_centroids, yoloV5_liteMono_framecount, (transformed_image_with_centroids.shape[1] - 100, transformed_image_with_centroids.shape[0] -20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2, cv2.LINE_AA)
                    


                    if save_bev_video:
                        if first_save_bev_video:
                            first_save_bev_video = False
                            # Output video parameters
                            output_path = 'bev_map.avi'

                            fourcc = cv2.VideoWriter_fourcc(*'XVID')          # 設定影片的格式為 XVID (for avi)
                            # fourcc = cv2.VideoWriter_fourcc(*'MJPG')          # 設定影片的格式為 MJPG (for mp4)
                            fps_out = 30.0  # Frames per second
                            # frame_size = (640, 480)  # Frame size (width, height)
                            frame_size = (transformed_image_with_centroids.shape[1], transformed_image_with_centroids.shape[0])  # Frame size (width, height)

                            # Create a VideoWriter object for the output video
                            bev_video_out = cv2.VideoWriter(output_path, fourcc, fps_out, frame_size)
                        bev_video_out.write(transformed_image_with_centroids)

                    # show image after save video
                    bev_frame_show_scale = 0.6

                    transformed_image_with_centroids = cv2.resize(transformed_image_with_centroids,None, fx=bev_frame_show_scale, fy=bev_frame_show_scale)

                    cv2.imshow('BEV Map', transformed_image_with_centroids)

                    if save_bev_warp_video:
                        if first_save_bev_warp_video:
                            first_save_bev_warp_video = False
                            # Output video parameters
                            output_path = 'bev_warp.avi'

                            fourcc = cv2.VideoWriter_fourcc(*'XVID')          # 設定影片的格式為 XVID (for avi)
                            # fourcc = cv2.VideoWriter_fourcc(*'MJPG')          # 設定影片的格式為 MJPG (for mp4)
                            fps_out = 30.0  # Frames per second
                            # frame_size = (640, 480)  # Frame size (width, height)
                            frame_size = (bev_warp_img.shape[1], bev_warp_img.shape[0])  # Frame size (width, height)

                            # Create a VideoWriter object for the output video
                            bev_warp_video_out = cv2.VideoWriter(output_path, fourcc, fps_out, frame_size)
                        bev_warp_video_out.write(bev_warp_img)
                        



                cv2.imshow('yolov5_lite-mono', yolov5_litemono_result)


        # Print time (inference-only)
        LOGGER.info(f"{s}{'' if len(det) else '(no detections), '}{dt[1].dt * 1E3:.1f}ms")

    # Print results
    t = tuple(x.t / seen * 1e3 for x in dt)  # speeds per image
    LOGGER.info(f"Speed: %.1fms pre-process, %.1fms inference, %.1fms NMS per image at shape {(1, 3, *imgsz)}" % t)
    if run_liteMono:
        print("Lite-mono speed: ", format((elapsed_time / frame_count) * 1000, '.1f'), "ms inference")
        if saveVideo_liteMono:
            out.release()
        if run_bev and save_bev_video:
            bev_video_out.release()
    if depth_log :
        depth_log_file.close()
            
    if save_txt or save_img:
        s = f"\n{len(list(save_dir.glob('labels/*.txt')))} labels saved to {save_dir / 'labels'}" if save_txt else ""
        LOGGER.info(f"Results saved to {colorstr('bold', save_dir)}{s}")
    if update:
        strip_optimizer(weights[0])  # update model (to fix SourceChangeWarning)


def parse_opt():
    """Parses command-line arguments for YOLOv5 detection, setting inference options and model configurations."""
    parser = argparse.ArgumentParser()
    parser.add_argument("--weights", nargs="+", type=str, default=ROOT / "yolov5s.pt", help="model path or triton URL")
    parser.add_argument("--source", type=str, default=ROOT / "data/images", help="file/dir/URL/glob/screen/0(webcam)")
    parser.add_argument("--data", type=str, default=ROOT / "data/coco128.yaml", help="(optional) dataset.yaml path")
    parser.add_argument("--imgsz", "--img", "--img-size", nargs="+", type=int, default=[640], help="inference size h,w")
    parser.add_argument("--conf-thres", type=float, default=0.25, help="confidence threshold")
    parser.add_argument("--iou-thres", type=float, default=0.45, help="NMS IoU threshold")
    parser.add_argument("--max-det", type=int, default=1000, help="maximum detections per image")
    parser.add_argument("--device", default="", help="cuda device, i.e. 0 or 0,1,2,3 or cpu")
    parser.add_argument("--view-img", action="store_true", help="show results")
    parser.add_argument("--save-txt", action="store_true", help="save results to *.txt")
    parser.add_argument("--save-csv", action="store_true", help="save results in CSV format")
    parser.add_argument("--save-conf", action="store_true", help="save confidences in --save-txt labels")
    parser.add_argument("--save-crop", action="store_true", help="save cropped prediction boxes")
    parser.add_argument("--nosave", action="store_true", help="do not save images/videos")
    parser.add_argument("--classes", nargs="+", type=int, help="filter by class: --classes 0, or --classes 0 2 3")
    parser.add_argument("--agnostic-nms", action="store_true", help="class-agnostic NMS")
    parser.add_argument("--augment", action="store_true", help="augmented inference")
    parser.add_argument("--visualize", action="store_true", help="visualize features")
    parser.add_argument("--update", action="store_true", help="update all models")
    parser.add_argument("--project", default=ROOT / "runs/detect", help="save results to project/name")
    parser.add_argument("--name", default="exp", help="save results to project/name")
    parser.add_argument("--exist-ok", action="store_true", help="existing project/name ok, do not increment")
    parser.add_argument("--line-thickness", default=3, type=int, help="bounding box thickness (pixels)")
    parser.add_argument("--hide-labels", default=False, action="store_true", help="hide labels")
    parser.add_argument("--hide-conf", default=False, action="store_true", help="hide confidences")
    parser.add_argument("--half", action="store_true", help="use FP16 half-precision inference")
    parser.add_argument("--dnn", action="store_true", help="use OpenCV DNN for ONNX inference")
    parser.add_argument("--vid-stride", type=int, default=1, help="video frame-rate stride")
    parser.add_argument("--run-liteMono", action="store_true", help="Run lite-mono")
    parser.add_argument("--run-bev", action="store_true", help="Run bev")
    parser.add_argument("--saveVideo-liteMono", action="store_true", help="Save video with lite-mono")
    parser.add_argument("--depth-log", action="store_true", help="Depth Log")
    parser.add_argument("--save-bev-video", action="store_true", help="Save video with bev map")
    parser.add_argument("--save-bev-warp-video", action="store_true", help="Save video with bev warp image")
    
    opt = parser.parse_args()
    opt.imgsz *= 2 if len(opt.imgsz) == 1 else 1  # expand
    print_args(vars(opt))
    return opt


def main(opt):
    """Executes YOLOv5 model inference with given options, checking requirements before running the model."""
    check_requirements(ROOT / "requirements.txt", exclude=("tensorboard", "thop"))
    run(**vars(opt))


if __name__ == "__main__":
    opt = parse_opt()
    main(opt)
