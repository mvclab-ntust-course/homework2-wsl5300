/*****************************************************************/
/**
 * File : main.js
 * Author : SHENG-HAO LIAO (frakwu@gmail.com)
 * Create Date : 2023-12-20
 * Editor : SHENG-HAO LIAO (frakwu@gmail.com)
 * Update Date : 2023-12-27
 * Description : three.js program for render a taxicar move on track points with stereoscopic render and interactive scene
 *********************************************************************/
import * as THREE from 'three';
import {DRACOLoader} from 'DRACOLoader';
import {GLTFLoader} from 'GLTFLoader';
import {MTLLoader} from 'MTLLoader';
import {OBJLoader} from 'OBJLoader';
import {EXRLoader} from 'EXRLoader';
import * as dat from 'dat.gui';

//basic component
var renderer;
var scene;
var leftEyeCamera;
var rightEyeCamera;

//dat gui variable
var gui;

//component for rendering env map
var sphere;
var sphereGeometry;
var sphereMaterial;

//some gui parameter for this program
var guiParameters = {
	currentTrackCenterIndex: 0, //integer for indexing taxiCar current location point in previous array
	taxiCarLaneOffset: 10, //put taxiCar on lane by offset from track center point
	chaseViewUpOffset: 50, //the distance of camera behind the taxiCar
	chaseViewBackwardOffset: 60, //the distance of camera above the taxiCar
	steroCameraOffset: 10 //stereo camera (left & right) distance to center line
}

//array for store track center points xyz coordinate and normal vector
let trackCenterPoints = [];
let trackCenterNormals = [];

let taxiCarScale =  0.8; // scale the taxiCar to the specific size

main();

function main() {
	//create empty scene
	scene = new THREE.Scene();

	// Create left eye camera
	leftEyeCamera = new THREE.PerspectiveCamera(80, (window.innerWidth - 16) / 2 / (window.innerHeight - 16), 0.01, 10000);
	leftEyeCamera.position.copy(new THREE.Vector3(0, 0, 0));

	// Create right eye camera
	rightEyeCamera = new THREE.PerspectiveCamera(80, (window.innerWidth - 16) / 2 / (window.innerHeight - 16), 0.01, 10000);
	rightEyeCamera.position.copy(new THREE.Vector3(0, 0, 0));

	//set up sphere geometry and material
	sphereGeometry = new THREE.SphereGeometry(5000, 64, 64);
	sphereMaterial = new THREE.MeshBasicMaterial();
	//need to use back side
	sphereMaterial.side = THREE.BackSide;
	sphereMaterial.map = new EXRLoader().load('images/hochsal_field_2k.exr');

	//create the sphere
	sphere = new THREE.Mesh(sphereGeometry, sphereMaterial);
	//set sphere position to origin point
	sphere.position.copy(new THREE.Vector3(0, 0, 0));
	//since the render side is back, so I use negative scale to reverse the image direction back
	sphere.scale.x = -1;
	//because the direction of texture is not same as marioKartStadium, so I rotate to fix that
	sphere.rotateX(degree2radian(90));
	//add sphere into scene
	scene.add(sphere);

	//some necessary variable for load .gltf/.glb file
	const dracoLoader = new DRACOLoader();
	dracoLoader.setDecoderPath('./lib/jsm/libs/draco/');
	var gltfLoader = new GLTFLoader();
	gltfLoader.setDRACOLoader(dracoLoader);

	//load MarioKartStadium.glb, and add into scene
	gltfLoader.load('./models/MarioKartStadium.glb', function(gltfObject) {
		var marioKartStadium = gltfObject.scene;
		//since some part of marioKartStadium is transparent
		//it will cause some problem when camera use some perspective to look (disappear)
		//so I set material.depthWrite to true to fix this problem
		marioKartStadium.traverse(function(child) {
			if (child.isMesh) {
				child.material.depthWrite = true;
			}
		});
		marioKartStadium.scale.setScalar(1.0);
		marioKartStadium.position.setScalar(0, 0, 0);
		marioKartStadium.name = 'MarioKartStadium';
		marioKartStadium.frustumCulled = false;
		scene.add(marioKartStadium);
	});

	//load TaxiCar.obj, and add into scene
	const objLoader = new OBJLoader();
	objLoader.load('./models/TaxiCar.obj', function(object) {
		object.name = 'TaxiCar';
		object.scale.setScalar(taxiCarScale);
		scene.add(object);
	});

	//load TaxiCar.mtl, and attach onto TaxiCar obj
	const mtlLoader = new MTLLoader();
	mtlLoader.load('./models/TaxiCar.mtl', function(materials) {
		materials.preload();
		objLoader.setMaterials(materials);
	});

	//read .xyz file and store every point info into two array below
	readXYZFile('TrackCenter.xyz', trackCenterPoints, trackCenterNormals).then(() => {
		//after loading the .xyz file, create the gui and attach every parameters
		gui = new dat.GUI({
			width: 400
		});
		gui.add(guiParameters, 'currentTrackCenterIndex', 0, trackCenterPoints.length - 1, 0).step(1).name('Track Index');
		gui.add(guiParameters, 'taxiCarLaneOffset', -30, 30, guiParameters.taxiCarLaneOffset).step(0.1).name('TaxiCar Lane Offset');
		gui.add(guiParameters, 'chaseViewUpOffset', 0.1, 100, guiParameters.chaseViewUpOffset).step(0.1).name('Chase View Up Offset');
		gui.add(guiParameters, 'chaseViewBackwardOffset', 0.1, 100, guiParameters.chaseViewBackwardOffset).step(0.1).name('Chase View Backward Offset');
		gui.add(guiParameters, 'steroCameraOffset', 0, 30, guiParameters.steroCameraOffset).step(0.1).name('Stereo Camera Offset');
	});

	//create axis helper
	var axisHelper = new THREE.AxesHelper(100);
	//create point light
	var pointLight = new THREE.PointLight(0xffffff, 10, 10000, 0.1);
	pointLight.position.set(100, -100, 500);
	const lighthelper = new THREE.PointLightHelper(pointLight);

	//add everything we need into scene
	scene.add(leftEyeCamera);
	scene.add(rightEyeCamera);
	scene.add(axisHelper);
	scene.add(pointLight);
	scene.add(lighthelper);

	//basic render setting
	renderer = new THREE.WebGLRenderer();
	renderer.setClearColor(0x888888, 1);
	//resize canvas into browser window size
	renderer.setSize(window.innerWidth - 16, window.innerHeight - 16);
	//renderer.
	document.body.appendChild(renderer.domElement);

	//callback to resize canvas into new windows size
	addEventListener("resize", () => {
		//update aspect after the window being resized
		leftEyeCamera.aspect = (window.innerWidth - 16) / 2 / (window.innerHeight - 16);
		rightEyeCamera.aspect = (window.innerWidth - 16) / 2 / (window.innerHeight - 16);
		leftEyeCamera.updateProjectionMatrix();
		rightEyeCamera.updateProjectionMatrix();
		renderer.setSize(window.innerWidth - 16, window.innerHeight - 16);
	}, false);

	//add mouse wheel event to move taxicar along the track
	window.addEventListener('wheel', function(event) {
		if (event.deltaY > 0) {
			moveTaxiCarBackward();
		} else {
			moveTaxiCarForward();
		}
	});

	//add keyboard press event to move taxicar along the track
	window.addEventListener('keydown', function(event) {
		switch (event.key) {
			case 'ArrowUp':
				moveTaxiCarForward();
				break;
			case 'ArrowDown':
				moveTaxiCarBackward();
				break;
		}
	});

	//animation update function
	animateFrame();
}
//read .xyz file and store every point info into trackCenterPoints and trackCenterNormals
function readXYZFile(filename, trackCenterPoints, trackCenterNormals) {
	return fetch(filename).then(response => response.text()).then(data => {
		//split text file into multiple lines
		const lines = data.split('\n');
		//loop throught every line
		lines.forEach(line => {
			//split single line into multiple word by space
			const values = line.split(' ');
			if (values.length == 6) {
				//create position and normal vector to store
				const position = new THREE.Vector3();
				const normal = new THREE.Vector3();
				//parse float from string
				position.x = parseFloat(values[0]);
				position.y = parseFloat(values[1]);
				position.z = parseFloat(values[2]);
				normal.x = parseFloat(values[3]);
				normal.y = parseFloat(values[4]);
				normal.z = parseFloat(values[5]);
				//add to array
				trackCenterPoints.push(position);
				trackCenterNormals.push(normal);
			}
		});
	}).catch(err => {
		console.error(err);
	});
}

//animation update function
function animateFrame() {
	//get object instance from scene by the name we set before
	let taxiCar = scene.getObjectByName('TaxiCar', true);

	//get current index
	let currentTrackCenterIndex = guiParameters.currentTrackCenterIndex;

	//get maximum track index
	let maxIndex = trackCenterPoints.length - 1;

	//if index is negative, set it to maxIndex
	if (currentTrackCenterIndex < 0) {
		currentTrackCenterIndex = maxIndex;
	}

	if (taxiCar) {
		//get next point index and next next point index
		let nextTrackCenterIndex = (currentTrackCenterIndex + 1) % maxIndex;
		let nextnextTrackCenterIndex = (currentTrackCenterIndex + 2) % maxIndex;

		//get position vectors
		let currentCenterPosition = trackCenterPoints[currentTrackCenterIndex];
		let nextCenterPosition = trackCenterPoints[nextTrackCenterIndex];
		let nextnextCenterPosition = trackCenterPoints[nextnextTrackCenterIndex];

		//get current point normal vector
		let currentNormal = trackCenterNormals[currentTrackCenterIndex];

		//According to midterm requirement we need car to be left side instead of center
		//get current position of taxiCar
		let currentTaxiCarPosition = getPostionOnLane(currentCenterPosition, nextCenterPosition, currentNormal, guiParameters.taxiCarLaneOffset);
		//get next position of taxiCar, since we need to lookat this point
		let nextTaxiCarPosition = getPostionOnLane(nextCenterPosition, nextnextCenterPosition, currentNormal, guiParameters.taxiCarLaneOffset);
		
		//set taxiCar position to the value we get previous
		taxiCar.position.copy(currentTaxiCarPosition);

		//set taxiCar up vector to the normal we get previous, this is important before we make taxiCar lookat next position.
		//it can ensure the rotation of taxiCar is correct 
		taxiCar.up.copy(currentNormal);

		//make taxiCar lookat next point, so the taxiCar's direction can align lane's direction
		taxiCar.lookAt(nextTaxiCarPosition);

		//because the head of the car is not facing the correct direction, it needs to be corrected by rotating the X-axis 90 degrees.
		taxiCar.rotateX(degree2radian(-90));

		//create camera backward vector
		const cameraBackwardVec = new THREE.Vector3();
		//calculate backward vector by subtracting current and next point
		cameraBackwardVec.subVectors(currentTaxiCarPosition, nextTaxiCarPosition);
		//normalize the camera backward vector, so we can multiply by offset
		cameraBackwardVec.normalize();
		//multiply by offset
		cameraBackwardVec.multiplyScalar(guiParameters.chaseViewBackwardOffset);

		//create camera upward vector
		let cameraUpVec = currentNormal;
		//normalize the upward vector, so we can multiply by offset
		cameraUpVec.normalize();
		//multiply by offset
		cameraUpVec.multiplyScalar(guiParameters.chaseViewUpOffset);

		//get left camera base position (on ground) using the current and next taxicar position by steroCameraOffset
		let leftCameraBasePosition = getPostionOnLane(currentTaxiCarPosition, nextTaxiCarPosition, currentNormal, guiParameters.steroCameraOffset);
		//get right camera base position (on ground) using the current and next taxicar position by steroCameraOffset
		let rightCameraBasePosition = getPostionOnLane(currentTaxiCarPosition, nextTaxiCarPosition, currentNormal, -guiParameters.steroCameraOffset);
		
		//create left camera final position
		let leftCameraPosition = new THREE.Vector3();
		//create right camera final position
		let rightCameraPosition = new THREE.Vector3();

		//add backward and upward vector on base position to get final position
		leftCameraPosition.addVectors(leftCameraBasePosition, cameraUpVec);
		leftCameraPosition.addVectors(leftCameraPosition, cameraBackwardVec);
		rightCameraPosition.addVectors(rightCameraBasePosition, cameraUpVec);
		rightCameraPosition.addVectors(rightCameraPosition, cameraBackwardVec);

		//set left camera position and lookat base position (make two camera direction parallel)
		leftEyeCamera.position.copy(leftCameraPosition);
		leftEyeCamera.up.copy(currentNormal);
		leftEyeCamera.lookAt(leftCameraBasePosition);

		//set right camera position and lookat base position (make two camera direction parallel)
		rightEyeCamera.position.copy(rightCameraPosition);
		rightEyeCamera.up.copy(currentNormal);
		rightEyeCamera.lookAt(rightCameraBasePosition);
	}

	//if the taxiCar move to the last point, then reset to first point for looping
	if (currentTrackCenterIndex > maxIndex) {
		currentTrackCenterIndex = 0;
	}	

	//use side-by-side render to get stereo view
	stereoCameraRender(renderer, leftEyeCamera, rightEyeCamera);

	//keep update frame
	requestAnimationFrame(animateFrame);
}

//get left/right offset point position on lane
//input current point, next point, normal vector and offset value
function getPostionOnLane(currentCenterPosition, nextCenterPosition, normalVec, offset) //offset >0 => left
{
	//create forward vector
	const forwardVec = new THREE.Vector3();

	//calculate forward vector by subtracting next and current point
	forwardVec.subVectors(nextCenterPosition, currentCenterPosition);

	//create left vector
	const leftVec = new THREE.Vector3();

	//calculate left vector by cross product to normal and forward vector
	leftVec.crossVectors(normalVec, forwardVec);

	//normalize the left vector, so we can multiply by offset
	leftVec.normalize();

	//multiply left vector by offset
	leftVec.multiplyScalar(offset);

	//create result vector
	const finalPosition = new THREE.Vector3();

	//calculate result vector by adding left vector to current point
	finalPosition.addVectors(currentCenterPosition, leftVec);

	//return result vector
	return finalPosition;
}

//a small function convert degree to radian
function degree2radian(degree) {
	return THREE.MathUtils.degToRad(degree);
}

//a function that move camera to next track index and update gui
function moveTaxiCarForward() {
	guiParameters.currentTrackCenterIndex += 1;
	if (guiParameters.currentTrackCenterIndex == trackCenterPoints.length) {
		guiParameters.currentTrackCenterIndex = 0;
	}
	gui.updateDisplay();
}

//a function that move camera to previous track index and update gui
function moveTaxiCarBackward() {
	guiParameters.currentTrackCenterIndex -= 1;
	if (guiParameters.currentTrackCenterIndex == -1) {
		guiParameters.currentTrackCenterIndex = trackCenterPoints.length - 1;
	}
	gui.updateDisplay();
}

//stereo camera view (side-by-side) render function
//input renderer, left & right camera
function stereoCameraRender(_renderer, _leftCamera, _rightCamera) {
	_renderer.setScissorTest(true);
	// render left camera view
	let _width = window.innerWidth / 2;
	let _height = window.innerHeight;
	_renderer.setScissor(0, 0, _width, _height);
	_renderer.setViewport(0, 0, _width, _height);
	_renderer.render(scene, _leftCamera);
	// render right camera view
	_renderer.setScissor(_width, 0, _width, _height);
	_renderer.setViewport(_width, 0, _width, _height);
	_renderer.render(scene, _rightCamera);
	_renderer.setScissorTest(false);
}