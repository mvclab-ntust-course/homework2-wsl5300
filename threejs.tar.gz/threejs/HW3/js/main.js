/*****************************************************************//**
 * File : main.js
 * Author : SHENG-HAO LIAO (frakwu@gmail.com)
 * Create Date : 2023-11-14
 * Editor : SHENG-HAO LIAO (frakwu@gmail.com)
 * Update Date : 2023-11-15
 * Description : three.js program for animate a satellite camera move around an earth equator
 *********************************************************************/
import * as THREE from 'three';
import { DRACOLoader } from 'DRACOLoader';
import { GLTFLoader } from 'GLTFLoader';
import { OrbitControls } from 'OrbitControls';

//basic component
var renderer;
var scene;

//homework3 specification
let earthCenterPosition = new THREE.Vector3(110,40,10);
let earthRadius = 50;

//program parameter
//split equator (circle) into 3600 little piece -> make continuous to discrete
let equatorSplitCount = 3600.0;
//angle for every piece (in degree)
let equatorSplitAngle = 360.0 / equatorSplitCount;
//current camera is located in which piece
let currentCameraAngle = equatorSplitCount / 2.0 * equatorSplitAngle;
//camera upper offset from earth grounds
let satelliteAltitude = 20.0;
//camera move speed factor
let speedFactor = 1.0;

//array for storing cameras 
let cameras = [];
//which camera camera index is in use
let currentRenderCameraIndex = 0;

//basic html ui setting and callback
uiSetting();

//main three.js program
main();

//a function for setting up ui component and callback function
function uiSetting()
{
	//get component instance
	const satelliteButton = document.getElementById('satelliteButton');
	const overallButton = document.getElementById('overallButton');
	const speedSlider = document.getElementById('speedSlider');
	const speedSliderText = document.getElementById('speedSliderText');
	const altitudeSlider = document.getElementById('altitudeSlider');
	const altitudeSliderText = document.getElementById('altitudeSliderText');
	//set callback function, so UI and variable can be update
	satelliteButton.addEventListener('click', function() {
		currentRenderCameraIndex = 0;
	});
	overallButton.addEventListener('click', function() {
		currentRenderCameraIndex = 1;
	});
	speedSlider.addEventListener('input', function() {
		speedFactor = speedSlider.value;
		speedSliderText.textContent = speedSlider.value;
	});
	altitudeSlider.addEventListener('input', function() {
		satelliteAltitude = altitudeSlider.value;
		altitudeSliderText.textContent = altitudeSlider.value;
	});
}

//main three.js program
function main()
{
	//create empty scene
	scene = new THREE.Scene();

	//satellite view camera
	let satelliteCamera = new THREE.PerspectiveCamera(45, (window.innerWidth-16) / (window.innerHeight-16), 5, 3000)
	//push into camera array
	cameras.push(satelliteCamera);

	//show satellite camera frusum in 3D scene
	const camHelper = new THREE.CameraHelper(satelliteCamera);

	//overall view camera (show satellite camera and earth)
	let overallCamera = new THREE.PerspectiveCamera(45, (window.innerWidth-16) / (window.innerHeight-16), 5, 3000)
	//default position for overall view camera
	overallCamera.position.set(75,-200, 80);
	//since our earth model are not in correct direction, so we need to follow its head dir.
	overallCamera.up.copy(new THREE.Vector3(0,0,1))
	//make camera look at center of earth
	overallCamera.lookAt(earthCenterPosition);
	//push into camera array
	cameras.push(overallCamera);

	//some necessary variable for load .gltf/.glb file
	const dracoLoader = new DRACOLoader();
	dracoLoader.setDecoderPath('./lib/jsm/libs/draco/');
	var gltfLoader = new GLTFLoader();
	gltfLoader.setDRACOLoader(dracoLoader);

	//load Earth.glb, and add into scene
	gltfLoader.load('./models/Earth.glb', function(object){
		var earth = object.scene;
		earth.scale.setScalar(1.0);
		earth.name = 'Earth';
		scene.add(earth);
	});

	//create axis helper
	var axisHelper = new THREE.AxesHelper(100);
	//create a light above camera 
	var headLight = new THREE.PointLight( 0xffffff, 10, 10000, 0.1);
	//set object name, so we can retrieve it later in another function
	headLight.name = "HeadLight";
	//show light position in 3D scene
	const lighthelper = new THREE.PointLightHelper(headLight);

	//add everything we need into scene
	scene.add(satelliteCamera);
	scene.add(overallCamera);
	scene.add(axisHelper);
	scene.add(headLight);
	scene.add(lighthelper);
	scene.add(camHelper);

	//basic render setting
	renderer = new THREE.WebGLRenderer();
	renderer.setClearColor(0x888888,1);
	//resize canvas into browser window size
	renderer.setSize(window.innerWidth-16,window.innerHeight-16);
	document.body.appendChild(renderer.domElement);

	//create control for camera
	let controls = new OrbitControls( overallCamera, renderer.domElement);
	controls.autoRotate = false;
	//default target is origin point, change into earth center
	controls.target = earthCenterPosition;
	controls.update();


	//callback to resize canvas into new windows size
	addEventListener("resize",() => {
		satelliteCamera.aspect = (window.innerWidth-16) / (window.innerHeight-16);
		satelliteCamera.updateProjectionMatrix();
		renderer.setSize(window.innerWidth-16, window.innerHeight-16);
		console.log(window.innerWidth,window.innerHeight);
	},false);

	//animation update function
	animateFrame();
}   

//animation update function
function animateFrame()
{
	//get object instance
	let satelliteCamera = cameras[0];
	let headLight = scene.getObjectByName('HeadLight',true);

	if (satelliteCamera && headLight)
	{
		//process flow : get circle point position -> lookat right dir -> move to final position
		//center point of a circle
		let cirleCenterPosition = new THREE.Vector3(0,0,0);

		//get current satellite camera position
		let currentCameraPosition = getSatellitePosition(earthRadius,currentCameraAngle, satelliteAltitude);
		//head light position, fixed in altitude 100
		let lightPosition = getSatellitePosition(earthRadius,currentCameraAngle, 100);
		//get 10 steps later satellite camera position (so we can look on it)
		let futureCameraPosition = getSatellitePosition(earthRadius,currentCameraAngle + equatorSplitAngle * 10,satelliteAltitude*0.90);
		
		//get camera up vector (reverse gravity) by using circle side to center direction.
		let cameraUpVec = new THREE.Vector3();
		cameraUpVec.subVectors(currentCameraPosition,cirleCenterPosition);
		cameraUpVec.normalize();

		//set satellite camera position
		satelliteCamera.position.copy(currentCameraPosition);
		//set satellite camera up vector (so we can correct lookat future position)
		satelliteCamera.up.copy(cameraUpVec);
		//look at future position
		satelliteCamera.lookAt(futureCameraPosition);

		//translate to real earth center position
		satelliteCamera.applyMatrix4(new THREE.Matrix4().makeTranslation(earthCenterPosition));
		
		//set head light position
		headLight.position.copy(lightPosition);
		//also translate to real earth center position
		headLight.applyMatrix4(new THREE.Matrix4().makeTranslation(earthCenterPosition));
	}

	//add current satellite camera angle by speedFactor times piece angle 
	currentCameraAngle += equatorSplitAngle * speedFactor;
	//if angle loop back to beginning, correction back to 0~360
	if(currentCameraAngle >= 360.0)
	{
		currentCameraAngle -= 360.0;
	}

	//render and set callback to keep update frame
	//use the camera we want to render the scene
	renderer.render(scene,cameras[currentRenderCameraIndex]);
	requestAnimationFrame(animateFrame);
}

//a function to get position above the earth equator
//input earth radius
//input current angle in equator ring
//input altitude (offset from equator ground)
function getSatellitePosition(earthRadius,equatorAngle,altitude)
{
	//get ground position on equator
	let earthGroundPosition = new THREE.Vector3(Math.cos(degree2radian(equatorAngle)) * earthRadius, Math.sin(degree2radian(equatorAngle)) * earthRadius,0);
	//calculate reverse gravity vector, and multi by altitude
	let radiusVec = new THREE.Vector3();
	radiusVec.subVectors(earthGroundPosition,new THREE.Vector3(0,0,0));
	radiusVec.normalize();
	radiusVec.multiplyScalar(altitude);
	//get final satellite position based on ground pos and altitude offset (reverse gravity vector)
	let satellitePosition = new THREE.Vector3();
	satellitePosition.addVectors(earthGroundPosition, radiusVec);
	return satellitePosition;
}

//a small function convert degree to radian
function degree2radian(degree)
{
	return degree * (Math.PI/180);
}


