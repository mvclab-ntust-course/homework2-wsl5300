/*****************************************************************//**
 * File : main.js
 * Author : SHENG-HAO LIAO (frakwu@gmail.com)
 * Create Date : 2023-12-05
 * Editor : SHENG-HAO LIAO (frakwu@gmail.com)
 * Update Date : 2023-12-05
 * Description : three.js program for rendering little planet and crystal ball effect from panorama image
 *********************************************************************/
import * as THREE from 'three';
import { OrbitControls } from 'OrbitControls';
import * as dat from 'dat.gui';

//basic component
var renderer;
var scene;
var mainCamera;

//component for rendering little planet and crystal ball effect
var sphere;
var sphereGeometry;
var sphereMaterial;
var controls;

//dat gui variable
var gui;

//variable for panoramaTexture GUI
var panoramaTextureGUI = {
    Filename: './images/20230704_095421.jpg'
}

//main three.js program
main();

//main three.js program
function main()
{
	//create empty scene
	scene = new THREE.Scene();

	//create camera, and set fov to 120, so the view can be wider
	mainCamera = new THREE.PerspectiveCamera(120, (window.innerWidth-16) / (window.innerHeight-16), 0.1, 1000);
	//set camera position to origin point (sphere position)
	mainCamera.position.copy(new THREE.Vector3(0,0,0));

	//set up sphere geometry and material
	sphereGeometry = new THREE.SphereGeometry(100, 64, 64);
	sphereMaterial = new THREE.MeshBasicMaterial();
	//need to use back side
	sphereMaterial.side = THREE.BackSide;

	//load default texture to material
	loadTextureToMaterial();

	//create the sphere
	sphere = new THREE.Mesh(sphereGeometry,sphereMaterial);
	//set sphere position to origin point
	sphere.position.copy(new THREE.Vector3(0,0,0));
	//since the render side is back, so I use negative scale to reverse the image direction back
	sphere.scale.x = -1;

	//add sphere into scene
	scene.add(sphere);

	//basic render setting
	renderer = new THREE.WebGLRenderer();
	renderer.setClearColor(0x888888,1);
	//resize canvas into browser window size
	renderer.setSize(window.innerWidth-16,window.innerHeight-16);
	document.body.appendChild(renderer.domElement);

	//create control for camera
	controls = new OrbitControls( mainCamera, renderer.domElement);
	//set orbit control target
	controls.target = sphere.position;
	controls.update();

	//add gui component
	gui = new dat.GUI({width : 400});

	//panorama part
	gui.addFolder("Panorama Texture");
	gui.add(panoramaTextureGUI, "Filename");
	var loadpanoramaTextureButton 	= 	{'Load Texture'	: 	loadTextureToMaterial};
	gui.add(loadpanoramaTextureButton,'Load Texture');

	//effect switch part
	gui.addFolder("Switch Effect");
	var littlePlanetButton 	= 	{'Little Planet'	: 	switchToLittlePlanet};
	var crystalBallButton 	= 	{'Crystal Ball'	: 	switchToCrystalBall};
	gui.add(littlePlanetButton,'Little Planet');
	gui.add(crystalBallButton,'Crystal Ball');

	//camera setting part
	gui.addFolder("Camera Setting");
	gui.add(mainCamera,'fov',45,150,0.1).onChange(function(){mainCamera.updateProjectionMatrix();});

	//use crystal ball effect as default
	switchToCrystalBall();

	//callback to resize canvas into new windows size
	addEventListener("resize",() => {
		mainCamera.aspect = (window.innerWidth-16) / (window.innerHeight-16);
		mainCamera.updateProjectionMatrix();
		renderer.setSize(window.innerWidth-16, window.innerHeight-16);
		console.log(window.innerWidth,window.innerHeight);
	},false);

	//animation update function
	animateFrame();
}

//load panorama texture into sphere material
function loadTextureToMaterial()
{
	const panoramaTexture = new THREE.TextureLoader().load(panoramaTextureGUI.Filename); 
	sphereMaterial.map = panoramaTexture;
}

//switch effect to little planet (camera inside sphere) (sphere radius:100)
function switchToLittlePlanet(){ 
	controls.minDistance = 0;
	controls.maxDistance = 99;
	controls.update();
}

//switch effect to crystal ball (camera outside sphere) (sphere radius:100)
function switchToCrystalBall(){ 
	controls.minDistance = 120;
	controls.maxDistance = 120;
	controls.update();
}

//animation update function
function animateFrame()
{
	//render and set callback to keep update frame
	renderer.render(scene,mainCamera);
	requestAnimationFrame(animateFrame);
}
